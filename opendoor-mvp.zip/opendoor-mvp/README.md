# OpenDoor — Student Opportunity Discovery MVP

A working Vercel-ready Next.js application for students in grades 6–12. No account, server database, AI API key, or payment integration is required.

## Quick start

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy with Vercel

1. Unzip this folder and push its files to a GitHub repository.
2. In Vercel choose **Add New → Project**, import the repository.
3. Keep framework **Next.js** and default build settings; no environment variables needed.
4. Deploy.

Or install the Vercel CLI and run `npx vercel` inside this folder.

## Working features

- Landing page; four-step onboarding; editable student profile.
- Personalized ranking with grade and known country eligibility gating, and additional filters for cost and remote accessibility.
- Searchable and filterable opportunity explorer and detail pages.
- Browser-persistent saved opportunities and application tracker with notes and statuses.
- Editable outreach email generator with tones, copy, and optional mailto handoff.
- Mobile-friendly navigation.

## Opportunity data and safety

`data/opportunities.json` currently contains a small starter catalog, including **directory and self-directed learning entry points clearly labeled as such**. Items come from established organizations and link to their official pages. This does **not** certify every program is open or fully grade-eligible. When application status is unknown it is labeled Unverified; age or district requirements need independent confirmation. Some dates are contest dates, not application deadlines. Please check the provider site before relying on any information. Expand the dataset with individually verified records rather than fabricated listings.

## Architecture

- Next.js App Router + TypeScript + Tailwind CSS + Lucide icons.
- Static JSON dataset; deterministic recommendation engine in `lib/match.ts`.
- localStorage keys: `od-profile`, `od-saved`, `od-tracker`.
- Browser-only persistence: switching browsers/devices or clearing website data loses saved content. No synced accounts.
- Matching score is relevance, not chance of acceptance.
- No automated emails are sent.

## Future improvements

Individually verify 50+ live programs, add richer location/age/citizenship eligibility and deadline metadata, project-specific contact details, opt-in sync, and optional server-side AI assistance.
