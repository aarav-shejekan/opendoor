import {defaultProfile,Profile,TrackerItem} from './types';
export function readProfile():Profile{if(typeof window==='undefined')return defaultProfile;try{return {...defaultProfile,...JSON.parse(localStorage.getItem('od-profile')||'{}')}}catch{return defaultProfile}}
export function saveProfile(p:Profile){localStorage.setItem('od-profile',JSON.stringify(p))}
export function readSaved():string[]{if(typeof window==='undefined')return [];try{return JSON.parse(localStorage.getItem('od-saved')||'[]')}catch{return []}}
export function saveSaved(a:string[]){localStorage.setItem('od-saved',JSON.stringify(a));window.dispatchEvent(new Event('od-change'))}
export function readTracker():Record<string,TrackerItem>{if(typeof window==='undefined')return {};try{return JSON.parse(localStorage.getItem('od-tracker')||'{}')}catch{return {}}}
export function saveTracker(a:Record<string,TrackerItem>){localStorage.setItem('od-tracker',JSON.stringify(a));window.dispatchEvent(new Event('od-change'))}
