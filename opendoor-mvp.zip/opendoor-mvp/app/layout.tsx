import './globals.css';import Shell from '@/components/Shell';
export const metadata={title:'OpenDoor | Find Your Next Opportunity',description:'Discover student opportunities tailored to you.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body><Shell>{children}</Shell></body></html>}
