import type { Config } from 'tailwindcss'
export default {content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],theme:{extend:{colors:{ink:'#101a36',primary:'#4358e8',muted:'#64748b'},boxShadow:{soft:'0 12px 38px rgba(25,37,89,.08)'}}},plugins:[]} satisfies Config
